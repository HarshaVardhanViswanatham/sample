package com.infosys.order_management.OrderMS.dto;


import com.infosys.order_management.OrderMS.entity.ProductsOrderedEntity;
public class ProductsorderedDTO {
	
	int ORDERID;
	int PRODID;
	int SELLERID;
	int QUANTITY;
	String STATUS;
	double price;
	
	public ProductsorderedDTO() {
		super();
	}
	
	public ProductsorderedDTO(int ORDERID,int PRODID,int SELLERID,int QUANTITY,String STATUS,double price) {
		this();
		this.ORDERID=ORDERID;
		this.PRODID=PRODID;
		this.SELLERID=SELLERID;
		this.QUANTITY=QUANTITY;
		this.STATUS=STATUS;
		this.price=price;
				
	}

	public int getORDERID() {
		return ORDERID;
	}

	public void setORDERID(int oRDERID) {
		ORDERID = oRDERID;
	}

	public int getPRODID() {
		return PRODID;
	}

	public void setPRODID(int pRODID) {
		PRODID = pRODID;
	}

	public int getSELLERID() {
		return SELLERID;
	}

	public void setSELLERID(int sELLERID) {
		SELLERID = sELLERID;
	}

	public int getQUANTITY() {
		return QUANTITY;
	}

	public void setQUANTITY(int qUANTITY) {
		QUANTITY = qUANTITY;
	}

	public String getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	// Converts Entity into DTO
	
	public static ProductsorderedDTO valueOf(ProductsOrderedEntity productsOrderedEntity){
		
		ProductsorderedDTO psd =new ProductsorderedDTO();
		
		psd.setORDERID(productsOrderedEntity.getORDERID());
		psd.setPRODID(productsOrderedEntity.getPRODID());
		psd.setSELLERID(productsOrderedEntity.getSELLERID());
		psd.setQUANTITY(productsOrderedEntity.getQUANTITY());
		psd.setSTATUS(productsOrderedEntity.getSTATUS());
		psd.setPrice(productsOrderedEntity.getPrice());
		
		return psd;
		
	}
	

}
