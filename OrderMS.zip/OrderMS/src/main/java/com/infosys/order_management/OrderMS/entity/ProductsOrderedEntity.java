package com.infosys.order_management.OrderMS.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "productsordered")
public class ProductsOrderedEntity {
	@Id
	@GeneratedValue
	int ORDERID;
	
	@Id
	@Column(name="PRODID")
	int PRODID;
	
	@Column(name="SELLERID")
	int SELLERID;
	
	@Column(name="QUANTITY")
	int QUANTITY;
	
	@Column(name="STATUS")
	String STATUS;
	
	@Column(name="price")
	double price;

	public int getORDERID() {
		return ORDERID;
	}

	public void setORDERID(int oRDERID) {
		ORDERID = oRDERID;
	}

	public int getPRODID() {
		return PRODID;
	}

	public void setPRODID(int pRODID) {
		PRODID = pRODID;
	}

	public int getSELLERID() {
		return SELLERID;
	}

	public void setSELLERID(int sELLERID) {
		SELLERID = sELLERID;
	}

	public int getQUANTITY() {
		return QUANTITY;
	}

	public void setQUANTITY(int qUANTITY) {
		QUANTITY = qUANTITY;
	}

	public String getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
