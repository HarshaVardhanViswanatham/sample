package com.infosys.order_management.OrderMS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.infosys.order_management.OrderMS.entity.ProductsOrderedEntity;


public interface ProductsRepository extends JpaRepository<ProductsOrderedEntity, Integer> {
	ProductsOrderedEntity findByPRODID(int PRODID);
	
}
