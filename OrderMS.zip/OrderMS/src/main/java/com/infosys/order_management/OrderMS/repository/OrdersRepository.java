package com.infosys.order_management.OrderMS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.order_management.OrderMS.entity.OrderDetailsEntity;

public interface OrdersRepository extends JpaRepository<OrderDetailsEntity, Long> {

	
}
