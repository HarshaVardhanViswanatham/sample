package com.infosys.order_management.OrderMS.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.infosys.order_management.OrderMS.dto.OrdersDetailsDTO;
import com.infosys.order_management.OrderMS.dto.ProductsorderedDTO;
import com.infosys.order_management.OrderMS.entity.OrderDetailsEntity;
import com.infosys.order_management.OrderMS.entity.ProductsOrderedEntity;
import com.infosys.order_management.OrderMS.repository.OrdersRepository;
import com.infosys.order_management.OrderMS.repository.ProductsRepository;



@Service
public class OrderService {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ProductsRepository ProductsRepo;
	
	
			
	public ProductsorderedDTO getProductDetails(@PathVariable int PRODID) {
		
		ProductsOrderedEntity productsOrderedEntity = ProductsRepo.findByPRODID(PRODID);
		ProductsorderedDTO productsorderedDTO = new ProductsorderedDTO();
		productsorderedDTO.valueOf(productsOrderedEntity);
		
		return productsorderedDTO;
	
	}

	
}
