package com.infosys.order_management.OrderMS.dto;

import java.sql.Date;

import com.infosys.order_management.OrderMS.entity.OrderDetailsEntity;

public class OrdersDetailsDTO {
	
	int ORDERID ;
	int BUYERID ;
	double AMOUNT ;
	Date DATE;
	String ADDRESS ;
	String STATUS ;
	
	public OrdersDetailsDTO() {
		super();
	}
	
	public OrdersDetailsDTO(int ORDERID,int BUYERID,double AMOUNT,Date DATE,String ADDRESS,String STATUS) {
		this();
		this.ORDERID=ORDERID;
		this.BUYERID=BUYERID;
		this.AMOUNT=AMOUNT;
		this.DATE=DATE;
		this.ADDRESS=ADDRESS;
		this.STATUS=STATUS;
		
	}

	public int getORDERID() {
		return ORDERID;
	}

	public void setORDERID(int oRDERID) {
		ORDERID = oRDERID;
	}

	public int getBUYERID() {
		return BUYERID;
	}

	public void setBUYERID(int bUYERID) {
		BUYERID = bUYERID;
	}

	public double getAMOUNT() {
		return AMOUNT;
	}

	public void setAMOUNT(double aMOUNT) {
		AMOUNT = aMOUNT;
	}

	public Date getDATE() {
		return DATE;
	}

	public void setDATE(Date dATE) {
		DATE = dATE;
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}

	public String getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	
	
	public static OrdersDetailsDTO valueOf(OrderDetailsEntity orderDetailsEntity){
		
		OrdersDetailsDTO ordersDetailsDTO =new OrdersDetailsDTO();
		ordersDetailsDTO.setORDERID(orderDetailsEntity.getORDERID());
		ordersDetailsDTO.setBUYERID(orderDetailsEntity.getBUYERID());
		ordersDetailsDTO.setAMOUNT(orderDetailsEntity.getAMOUNT());
		ordersDetailsDTO.setDATE(orderDetailsEntity.getDATE());
		ordersDetailsDTO.setADDRESS(orderDetailsEntity.getADDRESS());
		ordersDetailsDTO.setSTATUS(orderDetailsEntity.getSTATUS());
		
		return ordersDetailsDTO;
		
	}
	



	

}
